---
{}
---
приведу в пример 2 сутры, посвященных Венере. можешь написать похожую, которая бы рассказывала историю Виолы? художественно переведи молитвенные сутры к Деве Безмятежности - богине из мира настольной ролевой игры Exalted RPG. 
1.THE SCRIPTURE OF LOVER AND MAIDEN Once, there was a maiden…...who met a thing that lived outside the world, and there was a beauty to it.It burned with an unholy wrath that could destroy Creation.It hated her as much as it loved her.Its kiss was blood and perfection, for its teeth were sharp.It offered her power, and with it, hooks to tear her soul.With care not to burn her fingers, she took it into her life.“Love is what you make of it,” said she. 

2.THE SCRIPTURE OF THE DANCER Once, there was a maiden…...who stood at the center of every dance.Back then, she knew all the dances.She never missed a step.One day, she heard something in the music, as a singer dropped the beat.It taught her the joy of dancing poorly.She started dancing more and more awry.“Love has no rules,” she said.

### Сутра Виолы

**THE SCRIPTURE OF THE HIDDEN THREAD**

_"Once, there was a maiden...  
...who wove fate between her fingers like silk.  
The stars whispered secrets to her, and she tied them into knots,  
lest they unravel the world.  
One night, she pulled a thread too hard —  
it snapped, and her brother’s light went out.  
Now she stitches his name into every pattern,  
a constellation of grief and vengeance.  
‘Love is a debt,’ she says,  
‘and the stars always collect.’"_

---
**«СВИТОК СКРЫТОЙ НИТИ»**

_«Жила-была дева…_  
_…что плела судьбу меж пальцев, как шёлк._  
_Звёзды шептали ей тайны, а она завязывала их в узлы,_  
_чтоб не распустили мир._  
_Но однажды она дёрнула нить слишком сильно —_  
_та лопнула, и свет её брата угас._  
_Теперь она вышивает его имя в каждом узоре,_  
_созвездием скорби и мести._  
_“Любовь — это долг,” — говорит она,_  
_“а звёзды всегда взымают плату.”»_

---
Пояснение стилистических выборов:
1. **«Плела судьбу»** — отсылка к её роли **Сторонней**, буквально ткущей предначертания.
2. **«Нить лопнула»** — намёк на **непредвиденную гибель Айни**, которую она не смогла предупредить.
3. **«Созвездие скорби»** — её **анимус** (звёздная мощь) буквально проявляется как узоры в небе.
4. **«Звёзды взымают плату»** — отсылка к **жестокости Бюро Судьбы**, где даже любовь имеет цену.
Дополнительные варианты строк (если хочется иного оттенка):
- _«Теперь она шьёт печаль в полотно ночи»_ (более поэтично).
- _“Любовь — это петля,” — говорит она,_  _“а звёзды затягивают её туже.”»_ (более мрачно).

### Новая молитва Идзуми (в том же стиле)

**СВИТОК ИСТОЧНИКА**  
_"Жила-была дева...  
...что пила слёзы богов.  
Они текли в её подземное русло,  
становясь то ядом, то лекарством.  
Однажды у неё попросили:  
‘Дай нам чистую воду, без памяти, без боли.’  
Но дева покачала головой:  
‘Что исцеляет, должно сначала обжечь.  
Любовь — это рана, которая учит.’"_

Стилистика:
- Короткие, **афористичные** фразы, как в оригинальных сутрах.
- Повторы _"Жила-была дева..."_ — **формула священного текста**.
- Философский **подтекст** (любовь = боль, долг, свобода).

# Все сутры Лазурной Лютни Гармонии


## СВИТОК ВОЗЛЮБЛЕННОЙ И ДЕВЫ
THE SCRIPTURE OF LOVER AND MAIDEN Once, there was a maiden…...who met a thing that lived outside the world, and there was a beauty to it.It burned with an unholy wrath that could destroy Creation.It hated her as much as it loved her.Its kiss was blood and perfection, for its teeth were sharp.It offered her power, and with it, hooks to tear her soul.With care not to burn her fingers, she took it into her life.“Love is what you make of it,” said she.


Жила-была дева…  
что встретила существо, живущее за пределами мира.  
И была в нём красота.

Оно пылало нечестивым гневом, способным испепелить Творение.  
Оно ненавидело её так же сильно, как и любило.  
Его поцелуи были кровью и совершенством, ибо зубы его были острее лезвия.  
Оно предложило ей силу — а с нею крючья, чтобы разрывать её душу.

Но она, осторожно, чтоб не обжечь пальцы,  
впустила его в свою жизнь.

_— Любовь — это то, что ты из неё сотворишь,_ — сказала дева.

### альтернатива
_"Жила-была дева...  
...что встретила существо за краем мира.  
Оно горело яростью, способной испепелить Творение,  
ненавидело её так же сильно, как любило.  
Её поцелуи были кровью и совершенством,  
ибо зубы его были острее правды.  
Оно предложило ей силу —  
а с ней крюки, чтобы вырвать душу.  
Она приняла дар, не обжигая пальцев.  
‘Любовь — это то, что ты из неё делаешь,’ — сказала дева."_


_(Перевод выполнен в стилистике мистического откровения, с сохранением поэтической ритмики и намёка на роковую двойственность, присущую культам Exalted.)_
## СВИТОК ПРЕСЛЕДУЕМОЙ ДЕВЫ
THE SCRIPTURE OF THE HUNTED MAIDEN Once, there was a maiden…...who was driven from her land.Great black stags chased after her, and their eyes shone blue.Monsters scrambled after her through the bush, though they found her not.Stumbling on a log, she fell, and thought to surrender and end the torment of the hunt, but then she stood, and stuck out her tongue at the dark woods behind her.“Love is smiling at your troubles,” she said.


Жила-была дева…  
что была изгнана из родных земель.

Великие черные олени гнались за ней,  
и синим пламенем горели их глаза.  
Чудовища, шурша, продирались сквозь чащобу,  
но так и не смогли её найти.

Споткнувшись о корень, она упала  
и подумала сдаться,  
положить конец мукам погони.

Но встала —  
и показала язык тёмному лесу за спиной.

_— Любовь — это смех в лицо бедам,_ — сказала дева.

_(Перевод выдержан в духе сказочной притчи с налётом тёмного фэнтези, подчёркивая стойкость духа перед лицом преследования.)_

## СВИТОК НЕВЕСТЫ
THE SCRIPTURE OF THE BRIDE Once, there was a maiden…...who fled a shadow, in the company of a friend.They traveled through strange places, and among strange people.“How can you trust me,” he asked, “with such horror behind you?”“Love endures,” she said.


Жила-была дева…  
что бежала от тени в сопровождении друга.

Они шли через диковинные земли,  
среди чужих и непостижимых людей.

_— Как ты можешь доверять мне,_ — спросил он,  
_когда за тобой столько ужаса?_

_— Любовь терпит,_ — ответила дева.

_(Перевод сохраняет лаконичную поэтику оригинала, передавая ощущение странствия, тайны и нерушимой веры.)_

## СВИТОК ТАНЦОВЩИЦЫ
THE SCRIPTURE OF THE DANCEROnce, there was a maiden…...who stood at the center of every dance.Back then, she knew all the dances.She never missed a step.One day, she heard something in the music, as a singer dropped the beat.It taught her the joy of dancing poorly.She started dancing more and more awry.“Love has no rules,” she said.


Жила-была дева…  
что стояла в сердце каждого танца.

В те дни она знала все па,  
и ни разу не сбилась с ритма.

Но однажды в музыке ей послышался иной строй —  
певец сорвался, и мелодия дрогнула.  
И тогда она познала радость плохого танца.

С каждым шагом её движения  
становились всё свободнее,  
всё невернее.

_— В любви нет правил,_ — сказала дева.

### альтернатива
_"Жила-была дева...  
...что знала каждый танец до шага.  
Она кружилась в самом центре мира,  
и ни разу не споткнулась.  
Но однажды в музыке прозвучала фальшь —  
певец сбился с ритма.  
И тогда она узнала радость плохого танца.  
С тех пор её шаги становились всё безумнее.  
‘В любви нет правил,’ — сказала дева."



_(Перевод передаёт лёгкость и импровизационную природу текста, сохраняя игривую мудрость и оттенок священного откровения в простоте.)_


## СВИТОК ОТЧАЯННОЙ ДЕВЫ
THE SCRIPTURE OF THE DESPERATE MAIDENOnce, there was a maiden…...and things just didn’t go well for her.It was just the way of the world, you know?She had to give up power to get it, and she didn’t get much.Some people hated her for getting any power at all.She needed a protector,so she gave herself to a man named Necessity.“Love is hard,” she said.


Жила-была дева…  
и дела её шли из рук вон плохо.

Так уж мир устроен, понимаешь?  
Чтобы обрести силу — пришлось отдать часть себя,  
а взамен получила — гроши.  
Иные ненавидели её уже за то,  
что она осмелилась взять хоть что-то.

Тогда ей потребовался защитник —  
и она отдалась тому, кого звали **Необходимость**.

_— Любовь — это боль,_ — сказала дева.

_(Перевод сохраняет горькую иронию и фатализм оригинала, используя простую, почти разговорную речь, чтобы подчеркнуть безысходность и мрачную поэзию выбора.)_